================================================================================
  KarlsenMiner v2.4
  KarlsenHashV2 (FishHashPlus) GPU Miner
  OpenCL (AMD) + CUDA (NVIDIA)
================================================================================

OVERVIEW
--------
KarlsenMiner is a high-performance GPU miner for Karlsen (KLS) cryptocurrency
using the KarlsenHashV2 algorithm (FishHash + Blake3). It supports both AMD
GPUs via OpenCL and NVIDIA GPUs via CUDA in a single binary.

Features:
  - Dual backend: AMD OpenCL + NVIDIA CUDA (auto-detected)
  - Multi-pool with automatic failover
  - SSL/TLS support (Windows SChannel)
  - Per-GPU hashrate and share tracking
  - GPU monitoring: temperature, power, clocks, voltage, fan
  - Thermal protection with auto-pause/resume
  - NVIDIA GPU tuning via nvidia-smi (clock lock, power limit)
  - Per-GPU tuning with comma-separated values
  - EthereumStratum/1.0.0 protocol support


================================================================================
  QUICK START
================================================================================

Basic usage (all GPUs, SSL pool):

  karlsenminer.exe --pool stratum+ssl://pool.woolypooly.com:3132 --user YOUR_WALLET.worker1

Basic usage (local pool, no SSL):

  karlsenminer.exe --pool 192.168.0.155:5555 --user YOUR_WALLET.worker1

Benchmark mode (no pool, test hashrate):

  karlsenminer.exe --benchmark


================================================================================
  ALL COMMAND-LINE OPTIONS
================================================================================

Each option is listed with its syntax, default value, and a usage example.

────────────────────────────────────────────────────────────────────────────────
  POOL & AUTHENTICATION
────────────────────────────────────────────────────────────────────────────────

--pool URL
    Pool address. Can be repeated for failover (first = primary, rest = backup).
    Supported formats:
      host:port                        Plain TCP
      stratum+ssl://host:port          SSL/TLS
      stratum+tcp://host:port          Plain TCP (explicit)
      ssl://host:port                  SSL/TLS (short form)
    Default: none (required unless --benchmark)

    Examples:
      --pool stratum+ssl://pool.woolypooly.com:3132
      --pool 192.168.0.155:5555
      --pool stratum+ssl://pool1.example.com:3132 --pool pool2.example.com:5555

-o URL
    Alias for --pool (backward compatibility).

    Example:
      -o stratum+ssl://pool.woolypooly.com:3132


--user WORKER
    Worker name, typically wallet_address.worker_name.
    Default: none (required unless --benchmark)

    Examples:
      --user karlsen:qz...abc.rig1
      --user karlsen:qz...abc.mine4

-u WORKER
    Alias for --user.


--pass PASSWORD
    Pool password.
    Default: x

    Example:
      --pass mypassword

-p PASSWORD
    Alias for --pass.


--tls on|off
    Force SSL/TLS on all pool connections, even if the URL does not use
    stratum+ssl:// prefix.
    Default: auto (SSL only when URL starts with stratum+ssl:// or ssl://)

    Examples:
      --tls on          Force SSL on all connections
      --tls off         Disable SSL forcing (use URL scheme)


────────────────────────────────────────────────────────────────────────────────
  MULTI-POOL FAILOVER
────────────────────────────────────────────────────────────────────────────────

Multiple pools can be configured by repeating --pool and --user. The miner
connects to the first pool. If connection fails after 2 attempts, it switches
to the next pool in the list. When the primary pool comes back online, the
miner does NOT auto-switch back (stays on current working pool).

Example (2 pools with failover):

  karlsenminer.exe ^
    --pool 192.168.0.155:5555 --user wallet.rig1 ^
    --pool stratum+ssl://pool.woolypooly.com:3132 --user wallet.rig1

You can configure up to 4 pools (MAX_POOLS=4).


────────────────────────────────────────────────────────────────────────────────
  DEVICE SELECTION
────────────────────────────────────────────────────────────────────────────────

-d LIST
--devices LIST
    Select which GPUs to use. Accepts the following values:

    all       Use all available GPUs (AMD + NVIDIA). This is the default.
    amd       Use only AMD GPUs (OpenCL backend).
    nvidia    Use only NVIDIA GPUs (CUDA backend).
    0,1,2     Comma-separated GPU indices (0-based).
    0,1,2,3   Any combination of indices.

    Default: all

    Examples:
      -d all              Use all GPUs
      -d amd              AMD GPUs only
      -d nvidia           NVIDIA GPUs only
      -d 0,1,2,3,4,5      First 6 GPUs by index
      -d 0,2,4            Specific GPUs only
      --devices nvidia    NVIDIA only (long form)

    Note: GPU indices are assigned in the order GPUs are enumerated by OpenCL
    and CUDA. Use --benchmark to see which index corresponds to which GPU.


────────────────────────────────────────────────────────────────────────────────
  NVIDIA GPU TUNING
────────────────────────────────────────────────────────────────────────────────

These options control NVIDIA GPU hardware settings via nvidia-smi.
*** REQUIRES ADMINISTRATOR (Windows) or ROOT (Linux) PRIVILEGES ***
If the miner is not run as administrator, these settings will fail
with a WARNING message in the console.

AMD GPUs are NOT affected by these settings. Use AMD Radeon Software or
OverdriveNTool for AMD GPU tuning.

IMPORTANT: nvidia-smi uses its own GPU index (0, 1, 2, ...) which only
counts NVIDIA GPUs. If your system has AMD + NVIDIA GPUs, the nvidia-smi
indices do NOT match the --devices indices. The tuning values are applied
in order to nvidia-smi GPU 0, 1, 2, etc.

At startup, the miner runs "nvidia-smi -L" so you can verify which GPU
has which nvidia-smi index.


--cclk MHz[,MHz,...]
    Lock GPU core clock to a specific frequency (MHz).
    Uses nvidia-smi -lgc (lock graphics clocks).
    Comma-separated for per-GPU values: first value = nvidia-smi GPU 0, etc.
    If fewer values than GPUs, the last value is repeated.
    Default: not set (GPU boost decides)

    Examples:
      --cclk 1200           Lock ALL NVIDIA GPUs core at 1200 MHz
      --cclk 1200,1100      GPU0=1200 MHz, GPU1=1100 MHz
      --cclk 1200,1100,950  GPU0=1200, GPU1=1100, GPU2=950 MHz

    To reset: nvidia-smi -rgc


--mclk MHz[,MHz,...]
    Lock GPU memory clock to a specific frequency (MHz).
    Uses nvidia-smi -lmc (lock memory clocks).
    Comma-separated for per-GPU values.
    Default: not set (GPU decides)

    Examples:
      --mclk 9501           Lock all at 9501 MHz (GDDR6X)
      --mclk 9501,6801      GPU0=9501 MHz, GPU1=6801 MHz

    To reset: nvidia-smi -rmc


--pl WATTS[,WATTS,...]
    Set GPU power limit in watts.
    Uses nvidia-smi -pl.
    Comma-separated for per-GPU values.
    Default: not set (factory default)

    Examples:
      --pl 150              All GPUs = 150W
      --pl 190,150          GPU0=190W, GPU1=150W
      --pl 250,200,150      GPU0=250W, GPU1=200W, GPU2=150W


NOT SUPPORTED VIA NVIDIA-SMI:
    The following features are NOT available through nvidia-smi and require
    third-party tools like MSI Afterburner, EVGA Precision, or OverdriveNTool:

    - Core clock offset (--coff)  : nvidia-smi does not support -gco
    - Memory clock offset (--moff): nvidia-smi does not support -mco
    - Fan speed control (--fan)   : nvidia-smi does not support -fcs

    These parameters are accepted by the miner but will only print an
    informational message. Use MSI Afterburner for offset and fan control.


NVIDIA Tuning Example (.bat file):

  @echo off
  karlsenminer.exe ^
    --pool stratum+ssl://pool.woolypooly.com:3132 ^
    --user karlsen:qz...abc.mine5 ^
    -d 2,3 ^
    --cclk 1210,1110 ^
    --mclk 9501,6801 ^
    --pl 190,150 ^
    --tstop 85
  pause


────────────────────────────────────────────────────────────────────────────────
  THERMAL PROTECTION
────────────────────────────────────────────────────────────────────────────────

The miner can automatically pause individual GPUs when they exceed a
temperature threshold, and resume them when they cool down.

--tstop TEMP
    Pause a GPU when its core (edge) temperature reaches TEMP degrees Celsius.
    This is an alias for --gpu-off-temp.
    Default: disabled (0)

    Example:
      --tstop 80          Pause GPU at 80C, resume at 60C (default: off-20)

--gpu-off-temp TEMP
    Same as --tstop. Pause GPU at this temperature.
    Default: disabled (0)

    Example:
      --gpu-off-temp 85

--gpu-on-temp TEMP
    Resume a paused GPU when temperature drops to this value.
    Default: gpu-off-temp minus 20 (e.g., if --tstop 80, resume at 60C)

    Example:
      --gpu-off-temp 85 --gpu-on-temp 70

    Note: When a GPU is thermally paused, its row in the status table will
    show "PAUSED" in red instead of a hashrate value.


────────────────────────────────────────────────────────────────────────────────
  MINING SETTINGS
────────────────────────────────────────────────────────────────────────────────

-w N
--workload N
    Number of nonces per batch per GPU. Larger values increase GPU utilization
    but also increase latency for stale share detection.
    Default: 4194304 (4M = 2^22)

    Examples:
      -w 4194304          Default (4M nonces/batch)
      -w 8388608          8M nonces/batch (higher utilization, more latency)
      -w 2097152          2M nonces/batch (lower latency, less utilization)


--benchmark
    Run without connecting to a pool. Tests GPU hashrate with a dummy job.
    Useful for verifying GPU performance and stability.
    Default: off

    Example:
      karlsenminer.exe --benchmark
      karlsenminer.exe --benchmark -d nvidia
      karlsenminer.exe --benchmark -d 0,1


────────────────────────────────────────────────────────────────────────────────
  LOGGING & MISCELLANEOUS
────────────────────────────────────────────────────────────────────────────────

--log on|off
    Enable or disable file logging.
    Default: off

    Example:
      --log on

--logfile PATH
    Set the log file path. Implicitly enables --log on.
    Default: karlsenminer.log

    Examples:
      --logfile karlsenminer.log
      --logfile C:\logs\miner.log

--apiport PORT
    API port for remote monitoring (reserved, not yet implemented).
    Default: not set

    Example:
      --apiport 8020

-h
--help
    Show the built-in help message and exit.


────────────────────────────────────────────────────────────────────────────────
  COMPATIBILITY OPTIONS
────────────────────────────────────────────────────────────────────────────────

The following options are accepted for backward compatibility but are not
currently used:

  --watchdog VALUE      Accepted and ignored.
  --algo ALGORITHM      Accepted and ignored (only KarlsenHashV2 supported).


================================================================================
  STATUS TABLE COLUMNS
================================================================================

The miner displays a status table every ~30 seconds with the following columns:

  GPU    GPU index number
  Name   GPU model name (shortened, e.g., "CMP 90HX" instead of "NVIDIA CMP 90HX")
  Speed  Current local hashrate (measured from kernel execution time)
  A/R    Accepted/Rejected share count for this GPU
  Eff.   Energy efficiency in MH/s per Watt (higher = better)
  Power  GPU power draw in Watts
  Volt   GPU core voltage in millivolts (mV)
  CCLK   GPU core clock speed in MHz
  MCLK   GPU memory clock speed in MHz
  Core   GPU core (edge) temperature in Celsius
  Junc   GPU junction (hotspot) temperature in Celsius
  Fan    GPU fan speed as percentage

Summary line shows:
  Total  Current total hashrate across all GPUs
  avg    Session average hashrate
  A/R    Total accepted/rejected shares
  Power  Total power draw (all GPUs combined)
  Eff.   Total efficiency (total MH/s / total watts)
  Diff   Current mining difficulty from pool


================================================================================
  EXAMPLE .BAT FILES
================================================================================

--- Example 1: Simple single pool (all GPUs) ---

  @echo off
  karlsenminer.exe ^
    --pool stratum+ssl://pool.woolypooly.com:3132 ^
    --user wallet:karlsen:qzecljlvsd8h3x32ynuttzyya6s26p4p5p0gyztk7p984r25jp0y2s5fpdqhc.rig1
  pause


--- Example 2: NVIDIA only with per-GPU tuning (run as administrator) ---

  @echo off
  karlsenminer.exe ^
    --pool stratum+ssl://pool.woolypooly.com:3132 ^
    --user karlsen:qz...abc.mine5 ^
    -d 2,3 ^
    --cclk 1210,1110 ^
    --mclk 9501,6801 ^
    --pl 190,150 ^
    --tstop 85
  pause


--- Example 3: AMD only ---

  @echo off
  karlsenminer.exe ^
    --pool stratum+ssl://pool.woolypooly.com:3132 ^
    --user karlsen:qz...abc.mine3 ^
    -d amd ^
    --tstop 90 ^
    --gpu-on-temp 70
  pause


--- Example 4: Multi-pool failover with specific GPUs ---

  @echo off
  karlsenminer.exe ^
    --pool 192.168.0.155:5555 ^
    --user karlsen:qz...abc.rig1 ^
    --pool stratum+ssl://pool.woolypooly.com:3132 ^
    --user karlsen:qz...abc.rig1 ^
    -d 0,1,2,3,4,5 ^
    --gpu-off-temp 80
  pause


--- Example 5: NVIDIA tuning with thermal protection ---

  @echo off
  karlsenminer.exe ^
    --pool stratum+ssl://pool.woolypooly.com:3132 ^
    --user karlsen:qz...abc.mine5 ^
    -d nvidia ^
    --cclk 1200 ^
    --mclk 7001 ^
    --pl 150 ^
    --tstop 80 ^
    --gpu-on-temp 60 ^
    --tls on
  pause


--- Example 6: Benchmark specific GPUs ---

  @echo off
  karlsenminer.exe --benchmark -d nvidia
  pause


================================================================================
  TROUBLESHOOTING
================================================================================

Problem: "Failed to set power limit" / "Failed to lock core clock"
Solution: Right-click the .bat file -> "Run as administrator".
          NVIDIA GPU tuning requires admin privileges.

Problem: nvidia-smi tuning applies to wrong GPUs
Solution: nvidia-smi uses its own index (NVIDIA GPUs only, 0-based).
          If you have AMD + NVIDIA GPUs, nvidia-smi GPU 0 may not be
          --devices GPU 0. Check the "Detected NVIDIA GPUs" output at
          startup to verify which GPU is which index.

Problem: "No OpenCL GPUs found"
Solution: Install AMD Radeon drivers with OpenCL support.
          Or use -d nvidia to skip OpenCL enumeration.

Problem: "No CUDA GPUs found"
Solution: Install NVIDIA drivers (CUDA is included in modern drivers).
          Or use -d amd to skip CUDA enumeration.

Problem: "Connection lost" / frequent disconnects
Solution: Check network connection. Try --tls on for SSL.
          Add a second pool for failover.

Problem: GPU shows "PAUSED" in status table
Solution: GPU exceeded thermal limit (--tstop / --gpu-off-temp).
          It will resume automatically when cooled down.
          Reduce power limit (--pl) or use MSI Afterburner for fan control.

Problem: --coff / --moff / --fan not working
Solution: These features are NOT supported by nvidia-smi.
          Use MSI Afterburner or EVGA Precision for clock offsets
          and fan speed control.


================================================================================
  BUILD REQUIREMENTS
================================================================================

  - CMake 3.15+
  - OpenCL SDK (AMD APP SDK or system OpenCL headers)
  - CUDA Toolkit 12.x (for NVIDIA support)
  - C compiler: MSVC 2022 (Windows)
  - Windows: linked against ws2_32.lib, secur32.lib, crypt32.lib (SSL)
  - Static MSVC runtime (/MT) — no DLL dependencies

Build (Windows, MSVC + CUDA):

  mkdir build && cd build
  cmake .. -G "Visual Studio 17 2022" -A x64
  cmake --build . --config Release

Build output: build\Release\karlsenminer.exe (single file, no DLLs needed)


================================================================================
  LICENSE
================================================================================

KarlsenMiner is part of the Karlsen ecosystem.
https://github.com/karlsencoin


================================================================================
