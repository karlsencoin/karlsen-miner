@echo off
karlsenminer.exe --pool stratum+ssl://pool.woolypooly.com:3132 --user karlsen:qzecljlvsd8h3x32ynuttzyya6s26p4p5p0gyztk7p984r25jp0y2s5fpdqhc.test -d 0,1,2,3,4,5
pause